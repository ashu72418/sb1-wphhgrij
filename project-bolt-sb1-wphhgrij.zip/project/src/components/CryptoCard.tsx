import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { Cryptocurrency } from '../types';

interface CryptoCardProps {
  crypto: Cryptocurrency;
  onBuy: (id: string) => void;
  onSell: (id: string) => void;
}

export function CryptoCard({ crypto, onBuy, onSell }: CryptoCardProps) {
  const isPriceUp = crypto.price_change_percentage_24h >= 0;

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <img src={crypto.image} alt={crypto.name} className="w-10 h-10" />
          <div>
            <h3 className="font-bold text-lg">{crypto.name}</h3>
            <p className="text-gray-500 uppercase">{crypto.symbol}</p>
          </div>
        </div>
        <div className={`flex items-center ${isPriceUp ? 'text-green-500' : 'text-red-500'}`}>
          {isPriceUp ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
          <span className="ml-1">{crypto.price_change_percentage_24h.toFixed(2)}%</span>
        </div>
      </div>
      
      <div className="mb-4">
        <p className="text-2xl font-bold">${crypto.current_price.toLocaleString()}</p>
        <p className="text-gray-500">Market Cap: ${crypto.market_cap.toLocaleString()}</p>
      </div>
      
      <div className="flex space-x-3">
        <button
          onClick={() => onBuy(crypto.id)}
          className="flex-1 bg-green-500 text-white py-2 px-4 rounded-lg hover:bg-green-600 transition-colors"
        >
          Buy
        </button>
        <button
          onClick={() => onSell(crypto.id)}
          className="flex-1 bg-red-500 text-white py-2 px-4 rounded-lg hover:bg-red-600 transition-colors"
        >
          Sell
        </button>
      </div>
    </div>
  );
}