import React, { useEffect, useState } from 'react';
import { Header } from './components/Header';
import { CryptoCard } from './components/CryptoCard';
import { Cryptocurrency } from './types';

function App() {
  const [cryptocurrencies, setCryptocurrencies] = useState<Cryptocurrency[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchCryptocurrencies();
    const interval = setInterval(fetchCryptocurrencies, 60000); // Refresh every minute
    return () => clearInterval(interval);
  }, []);

  const fetchCryptocurrencies = async () => {
    try {
      const response = await fetch(
        'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=12&page=1&sparkline=false'
      );
      if (!response.ok) throw new Error('Failed to fetch data');
      const data = await response.json();
      setCryptocurrencies(data);
      setLoading(false);
    } catch (err) {
      setError('Failed to fetch cryptocurrency data. Please try again later.');
      setLoading(false);
    }
  };

  const handleBuy = (id: string) => {
    // Implement buy functionality
    console.log('Buy', id);
  };

  const handleSell = (id: string) => {
    // Implement sell functionality
    console.log('Sell', id);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
          </div>
        ) : error ? (
          <div className="text-center text-red-500 p-4 bg-red-50 rounded-lg">
            {error}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {cryptocurrencies.map((crypto) => (
              <CryptoCard
                key={crypto.id}
                crypto={crypto}
                onBuy={handleBuy}
                onSell={handleSell}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

export default App;